package com.Innobyte.Innobyte.service;

import com.Innobyte.Innobyte.model.Quiz;
import com.Innobyte.Innobyte.repository.QuizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuizService {

    @Autowired
    private QuizRepository quizRepository;

    // Create a new quiz
    public Quiz createQuiz(Quiz quiz) {
        return quizRepository.save(quiz);
    }

    // Get all quizzes
    public List<Quiz> getAllQuizzes() {
        return quizRepository.findAll();
    }

    // Get a quiz by its ID
    public Optional<Quiz> getQuizById(Long id) {
        return quizRepository.findById(id);
    }

    // Update an existing quiz
    public Optional<Quiz> updateQuiz(Long id, Quiz quizDetails) {
        Optional<Quiz> existingQuiz = quizRepository.findById(id);
        if (existingQuiz.isPresent()) {
            Quiz quizToUpdate = existingQuiz.get();
            quizToUpdate.setTitle(quizDetails.getTitle());
            quizToUpdate.setDescription(quizDetails.getDescription());
            quizToUpdate.setQuestions(quizDetails.getQuestions());
            return Optional.of(quizRepository.save(quizToUpdate));
        }
        return Optional.empty();
    }

    // Delete a quiz by its ID
    public boolean deleteQuiz(Long id) {
        if (quizRepository.existsById(id)) {
            quizRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
