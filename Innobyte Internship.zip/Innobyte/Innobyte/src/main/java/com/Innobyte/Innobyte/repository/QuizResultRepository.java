package com.Innobyte.Innobyte.repository;

import com.Innobyte.Innobyte.model.QuizResult;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuizResultRepository extends JpaRepository<QuizResult, Long> {
    // Custom query methods can be defined here
}
