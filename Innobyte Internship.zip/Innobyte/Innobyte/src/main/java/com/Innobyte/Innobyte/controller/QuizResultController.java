package com.Innobyte.Innobyte.controller;

import com.Innobyte.Innobyte.model.QuizResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/quiz-results")
public class QuizResultController {

    @Autowired
    private QuizResultService quizResultService;

    // Create a new quiz result
    @PostMapping
    public ResponseEntity<QuizResult> createQuizResult(@RequestBody QuizResult quizResult) {
        QuizResult savedQuizResult = quizResultService.createQuizResult(quizResult);
        return new ResponseEntity<>(savedQuizResult, HttpStatus.CREATED);
    }

    // Get all quiz results
    @GetMapping
    public ResponseEntity<List<QuizResult>> getAllQuizResults() {
        List<QuizResult> quizResults = quizResultService.getAllQuizResults();
        return new ResponseEntity<>(quizResults, HttpStatus.OK);
    }

    // Get a specific quiz result by ID
    @GetMapping("/{id}")
    public ResponseEntity<QuizResult> getQuizResultById(@PathVariable Long id) {
        Optional<QuizResult> quizResult = quizResultService.getQuizResultById(id);
        return quizResult.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Get all quiz results for a specific user
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<QuizResult>> getQuizResultsByUserId(@PathVariable Long userId) {
        List<QuizResult> quizResults = quizResultService.getQuizResultsByUserId(userId);
        return new ResponseEntity<>(quizResults, HttpStatus.OK);
    }

    // Update an existing quiz result
    @PutMapping("/{id}")
    public ResponseEntity<QuizResult> updateQuizResult(@PathVariable Long id, @RequestBody QuizResult quizResultDetails) {
        Optional<QuizResult> updatedQuizResult = quizResultService.updateQuizResult(id, quizResultDetails);
        return updatedQuizResult.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Delete a quiz result
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteQuizResult(@PathVariable Long id) {
        boolean isDeleted = quizResultService.deleteQuizResult(id);
        return isDeleted ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
