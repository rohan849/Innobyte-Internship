package com.Innobyte.Innobyte.service;

import com.Innobyte.Innobyte.model.QuizResult;
import com.Innobyte.Innobyte.repository.QuizResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuizResultService {

    @Autowired
    private QuizResultRepository quizResultRepository;

    // Create a new quiz result
    public QuizResult createQuizResult(QuizResult quizResult) {
        return quizResultRepository.save(quizResult);
    }

    // Get all quiz results
    public List<QuizResult> getAllQuizResults() {
        return quizResultRepository.findAll();
    }

    // Get a quiz result by ID
    public Optional<QuizResult> getQuizResultById(Long id) {
        return quizResultRepository.findById(id);
    }

    // Get all quiz results for a specific user
    public List<QuizResult> getQuizResultsByUserId(Long userId) {
        return quizResultRepository.findAll(); // Implement custom query if necessary
    }

    // Update a quiz result
    public Optional<QuizResult> updateQuizResult(Long id, QuizResult quizResultDetails) {
        Optional<QuizResult> existingQuizResult = quizResultRepository.findById(id);
        if (existingQuizResult.isPresent()) {
            QuizResult quizResultToUpdate = existingQuizResult.get();
            quizResultToUpdate.setScore(quizResultDetails.getScore());
            quizResultToUpdate.setAttemptDate(quizResultDetails.getAttemptDate());
            quizResultToUpdate.setUser(quizResultDetails.getUser());
            quizResultToUpdate.setQuiz(quizResultDetails.getQuiz());
            return Optional.of(quizResultRepository.save(quizResultToUpdate));
        }
        return Optional.empty();
    }

    // Delete a quiz result
    public boolean deleteQuizResult(Long id) {
        if (quizResultRepository.existsById(id)) {
            quizResultRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
