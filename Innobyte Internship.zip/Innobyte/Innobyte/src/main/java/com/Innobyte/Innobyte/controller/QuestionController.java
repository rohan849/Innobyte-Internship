package com.Innobyte.Innobyte.controller;

import com.Innobyte.Innobyte.model.Question;
import com.Innobyte.Innobyte.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/questions")
public class QuestionController {

    @Autowired
    private QuestionRepository questionRepository;

    // ✅ Add a new question
    @PostMapping
    public String addQuestion(@RequestBody Question question) {
        questionRepository.save(question);
        return "Question added successfully!";
    }

    // ✅ Update an existing question
    @PutMapping("/{id}")
    public String updateQuestion(@PathVariable Long id, @RequestBody Question updatedQuestion) {
        Optional<Question> optionalQuestion = questionRepository.findById(id);

        if (optionalQuestion.isPresent()) {
            Question question = optionalQuestion.get();
            question.setTitle(updatedQuestion.getTitle());
            question.setOptionA(updatedQuestion.getOptionA());
            question.setOptionB(updatedQuestion.getOptionB());
            question.setOptionC(updatedQuestion.getOptionC());
            question.setOptionD(updatedQuestion.getOptionD());
            question.setCorrectAnswer(updatedQuestion.getCorrectAnswer());
            questionRepository.save(question);
            return "Question updated successfully!";
        } else {
            return "Question not found!";
        }
    }

    // ✅ Delete a question
    @DeleteMapping("/{id}")
    public String deleteQuestion(@PathVariable Long id) {
        if (questionRepository.existsById(id)) {
            questionRepository.deleteById(id);
            return "Question deleted successfully!";
        } else {
            return "Question not found!";
        }
    }
}
